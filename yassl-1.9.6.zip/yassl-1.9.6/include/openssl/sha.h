/* sha.h  for openvpn */
