/* lhash.h for openSSL */

